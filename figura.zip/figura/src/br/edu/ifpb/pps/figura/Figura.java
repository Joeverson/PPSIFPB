package br.edu.ifpb.pps.figura;

public interface Figura {
	void draw();
	double perimetro();
}
