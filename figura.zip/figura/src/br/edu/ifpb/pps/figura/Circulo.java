package br.edu.ifpb.pps.figura;

public class Circulo implements Figura{
	private Ponto p1;
	private Ponto p2;
	
	public Circulo(Ponto p1, Ponto p2){
		this.p1 = p1;
		this.p2 = p2;
	}
	
	public void draw(){
		System.out.println("estou desenhando um circulo");
	}
	
	public double perimetro(){
		double pi = Math.PI;
		double raio = Math.sqrt(Math.pow(p2.getX()-p1.getX(), 2)+Math.pow(p2.getY()-p1.getY(), 2));

		return 2*pi*raio;
	}
	
	public void area(){}
}
